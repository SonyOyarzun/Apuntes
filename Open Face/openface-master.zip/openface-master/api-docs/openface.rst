openface package
================

openface.AlignDlib class
------------------------
.. autoclass:: openface.AlignDlib
    :members:
    :undoc-members:
    :show-inheritance:

openface.TorchNeuralNet class
-----------------------------
.. autoclass:: openface.TorchNeuralNet
    :members:
    :undoc-members:
    :show-inheritance:


openface.data module
--------------------

.. automodule:: openface.data
    :members:
    :undoc-members:
    :show-inheritance:

openface.helper module
----------------------

.. automodule:: openface.helper
    :members:
    :undoc-members:
    :show-inheritance:
